The block_models module
=================================================

This module contains a series of function that can generate random graphs with a signed community structure. 

.. automodule:: block_models
    :members:

