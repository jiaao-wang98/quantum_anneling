The utils module
================

The utils module mainly contains functions that are used elsewhere in the package.
It also contains the function *objscore* calculating the value of an arbitrary objective function on a given graph partition.

.. automodule:: utils
    :members:
